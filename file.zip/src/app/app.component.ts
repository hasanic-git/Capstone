import { Component, OnInit } from '@angular/core';
import { CapstoneService } from './capstone.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent implements OnInit {
  title = 'Capstone';
  //declare variable to hold response and make it public to be accessible from components.html
  public capstones: any;
  //initialize the call using CapstoneService 
  constructor(private _myService: CapstoneService) { }
  ngOnInit() {
    this.getCapstones();
  }

  //method called OnInit
  getCapstones() {

    this._myService.getCapstones().subscribe({
      next: (data) => { this.capstones = data },
      error: (err) => { console.error(err) },
      complete: () => { console.log('finished loading') }
    });

    // this._myService.getCapstones().subscribe(
    //     //read data and assign to public variable students
    //     data => { this.capstones = data},
    //     err => console.error(err),
    //     () => console.log('finished loading')
    // );
  }

  onDelete(projectId: string) {
    this._myService.deleteProject(projectId);
  }

}
