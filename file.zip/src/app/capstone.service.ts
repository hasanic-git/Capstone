import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';


//we know that response will be in JSON format
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable()
export class CapstoneService {

    constructor(private http: HttpClient) { }

    // Uses http.get() to load data 
    getCapstones() {
        return this.http.get('http://localhost:8000/capstone');
    }

    //Uses http.post() to post data 
    addCapstone(capstone: any) {
        this.http.post('http://localhost:8000/capstone', capstone)
            .pipe(
                catchError((error) => {
                    console.error('POST request failed', error);
                    return of(null); // You can also return a default value if needed
                })
            )
            .subscribe((response) => {
                console.log('POST message:', response);
                if (response) {
                    //successful
                    this.reloadPage();
                }
            });
    }

    deleteProject(projectId: string) {
        this.http.delete("http://localhost:8000/capstone/" + projectId)
            .subscribe(() => {
                console.log('Deleted: ' + projectId);
                this.reloadPage();
            });
    }

    reloadPage() {
        window.location.reload()
    }

}
