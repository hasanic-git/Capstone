import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import ZipCodes from 'src/assets/zip-codes.json';
import { CapstoneService } from '../capstone.service';

@Component({
  selector: 'app-proposal-editor',
  templateUrl: './proposal-editor.component.html',
  styleUrls: ['./proposal-editor.component.css']
})

export class ProposalEditorComponent {

    //initialize the call using CapstoneService 
    constructor(private _myService: CapstoneService) { }
  
    zipCodes: { zip_code: number, city: string, state: string }[] = ZipCodes;

    proposalForm = new FormGroup({
      contactName: new FormControl('', [
        Validators.required,
        Validators.minLength(2)
      ]),
      jobTitle: new FormControl('', [
        Validators.required,
        Validators.minLength(2)
      ]),
      contactEmail: new FormControl('', [
        Validators.required,
        Validators.email
      ]),
      contactPhone: new FormControl('', [
        Validators.required,
        Validators.minLength(2)
      ]),
      
      address: new FormGroup({
        street: new FormControl('', [
          Validators.required,
          Validators.minLength(2)
        ]),
        city: new FormControl('', [
          Validators.required,
          Validators.minLength(2)
        ]),
        state: new FormControl('', [
          Validators.required,
          Validators.minLength(2)
        ]),
        zip: new FormControl('', [
          Validators.required,
          Validators.minLength(2)
        ])
      }),

      projectTitle: new FormControl('', [
        Validators.required,
        Validators.minLength(2)
      ]),
      projectDescription: new FormControl('', [
        Validators.required,
        Validators.minLength(4)
      ]),
      technicalSkill: new FormControl('', [
        Validators.required,
        Validators.minLength(2)
      ]),

    });
  
    onSubmit() {
      console.log(this.proposalForm.value);

      let formObj = this.proposalForm.getRawValue();
      //let serializedForm = JSON.stringify(formObj);
      //this._myService.addStudents(this.firstName ,this.lastName);
      this._myService.addCapstone(formObj);

      //reload the contents
      // call the get api
      //window.location.reload();

    }

    zipCodeChanged() {

      let zipCodeStr = this.proposalForm.value.address?.zip;

      if (!zipCodeStr) {
        this.resetCityInfo();
        return;
      }

      if (!isNaN(Number(zipCodeStr))) {
        let zipCode = Number(zipCodeStr);
        console.log('zipCode is Number: %s', zipCode);
        this.findCityInfo(zipCode);
      } else {
        console.log('zipCode is Str: %s', zipCodeStr);
        this.resetCityInfo();
      }
    }
  
    resetCityInfo() {
      this.proposalForm.patchValue({
        address: {
          city: '',
          state: ''
        }
      });
    }
  
    findCityInfo(zipCode: Number) {
      var success: boolean = false;
  
      for (var zipCodeObj of this.zipCodes) {
        if (zipCodeObj.zip_code == zipCode) {
          success = true;
          this.proposalForm.patchValue({
            address: {
              city: zipCodeObj.city,
              state: zipCodeObj.state
            }
          });
          break;
        }
      }
  
      if (!success) {
        this.resetCityInfo();
      }
    }

  }
  